export const CommonDefs = /* GraphQL */`
    type UserError {
        message: String!
        code: String
    }
`;