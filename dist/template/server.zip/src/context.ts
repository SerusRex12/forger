import { Prisma, PrismaClient, User } from '@prisma/client';
import { createPubSub, YogaInitialContext } from 'graphql-yoga';
import { authenticateUser } from './auth';
import { getUserFromToken } from "./utils/getUserFromToken";


const pubSub = createPubSub<{
    randomNumber: [randomNumber: number]
}>()

export const prisma = new PrismaClient()

export type Context = {
    prisma: PrismaClient<
    Prisma.PrismaClientOptions,
    never,
    Prisma.RejectOnNotFound | Prisma.RejectPerOperation | undefined
  >;
  // currentUser: null | User;
  userInfo: {
    userId: number;
  } | null;
 pubSub: any;
}

export async function createContext(initialContext: YogaInitialContext): Promise<Context> {
    let token = initialContext.request.headers.get('authorization');
    return {
      prisma,
      // currentUser: await authenticateUser(prisma, initialContext.request),
      pubSub,
      userInfo : await getUserFromToken(token ?? '')
    }
}