import { makeExecutableSchema } from '@graphql-tools/schema';
import { Query, Mutation } from './resolvers';
import { CommonDefs } from "./typedefs";

const { GraphQLScalarType, Kind } = require('graphql');

const dateScalar = new GraphQLScalarType({
  name: 'Date',
  description: 'Date custom scalar type',
  serialize(value: { getTime: () => any; }) {
    return value.getTime(); // Convert outgoing Date to integer for JSON
  },
  parseValue(value: string | number | Date) {
    return new Date(value); // Convert incoming integer to Date
  },
  parseLiteral(ast: { kind: any; value: string; }) {
    if (ast.kind === Kind.INT) {
      return new Date(parseInt(ast.value, 10)); // Convert hard-coded AST string to integer and then to Date
    }
    return null; // Invalid hard-coded value (not an integer)
  },
});

const typeDefinitions = [
  /* GraphQL */`
    scalar Date
    type Query
    type Mutation
    type Subscription
  `,
  CommonDefs,
];

const resolvers = {
  Date: dateScalar,
  Query,
  Mutation,
};

export const schema = makeExecutableSchema({
  resolvers: [resolvers],
  typeDefs: [typeDefinitions]
});