export const Sample = {

}