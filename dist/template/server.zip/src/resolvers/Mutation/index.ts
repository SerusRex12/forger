import { CommonMutation } from "./commonMutate";


export const Mutation = {
  ...CommonMutation
};
