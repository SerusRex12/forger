import { Context } from "../../context";

export const CommonMutation = {

};
