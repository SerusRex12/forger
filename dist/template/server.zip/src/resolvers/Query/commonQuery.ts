import { Context } from "../../context";


export const CommonQuery = {

}