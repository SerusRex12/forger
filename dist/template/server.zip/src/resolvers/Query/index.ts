import { Context } from "../../context";
import { CommonQuery } from "./commonQuery";

export const Query = {
  ...CommonQuery
};
