export interface CommonInterface {
    userErrors: {
        message: string;
        code?: string;
    }[];
}